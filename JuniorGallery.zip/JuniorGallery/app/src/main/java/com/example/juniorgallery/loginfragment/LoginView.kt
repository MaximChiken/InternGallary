package com.example.juniorgallery.loginfragment

interface LoginView {
}