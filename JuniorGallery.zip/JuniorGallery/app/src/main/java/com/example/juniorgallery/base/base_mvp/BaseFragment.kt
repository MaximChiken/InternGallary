package com.example.juniorgallery.base.base_mvp

import androidx.viewbinding.ViewBinding
import moxy.MvpAppCompatFragment

abstract class BaseFragment<VB : ViewBinding> : MvpAppCompatFragment() {


}