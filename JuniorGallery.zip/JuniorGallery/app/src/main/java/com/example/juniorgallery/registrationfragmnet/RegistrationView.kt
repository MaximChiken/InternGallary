package com.example.juniorgallery.registrationfragmnet

interface RegistrationView {
}