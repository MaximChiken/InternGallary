package com.example.juniorgallery.registrationfragmnet

import androidx.fragment.app.Fragment

class RegistrationFragment: Fragment() {
}