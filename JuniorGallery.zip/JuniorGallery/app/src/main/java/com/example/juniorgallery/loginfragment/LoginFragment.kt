package com.example.juniorgallery.loginfragment

import androidx.fragment.app.Fragment

class LoginFragment: Fragment() {
}