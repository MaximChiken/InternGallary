package com.example.juniorgallery.base.base_mvp

import moxy.MvpView

interface BaseView:MvpView {
}